# define class
class Cat:
    # constructor for naming a cat
    def __init__(self, name1, name2):
        self.name1 = name1
        self.name2 = name2

    def introduce_and_greet(self):
        print("\nMy name is " + self.name1 + "! I see you are also a cool fluffy kitty " + self.name2 + ", let's together purr at the human, so that they shall give us food. \n")

    def introduce_and_greet2(self):
        print("My name is " + self.name2 + "! That is a great idea " + self.name1 + ", let's get going.")





