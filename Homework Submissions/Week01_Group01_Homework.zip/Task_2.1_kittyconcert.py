import cat

# define objects
cat.getNames = cat.Cat(input("Enter name of first cat: "), input("Enter name of second cat: "))

cat.getNames.introduce_and_greet()
cat.getNames.introduce_and_greet2()