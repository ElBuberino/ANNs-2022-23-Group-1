# Task 1: List of squares of each number between 0 and 100
print([x*x for x in range(1,101)])

# Task 2: Same list, only even numbers
print([x*x for x in range(1,101) if x % 2 == 0])





