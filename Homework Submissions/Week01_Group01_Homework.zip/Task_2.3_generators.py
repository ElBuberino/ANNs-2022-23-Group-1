# Double the amount of "Meows" for every generation
def meow_generator(generation):
        for i in range(0,generation):
            x = 2**i
            yield(x*"Meow ")

# Indicate how many generations of "Meows" shall be printed
my_meows = meow_generator(4)

# Iterate over all generations
for i in my_meows:
    print(i)

""" Alternative iteration implementation
print(next(my_meows))
print(next(my_meows))
print(next(my_meows))
print(next(my_meows)) """