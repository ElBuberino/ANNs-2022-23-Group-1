import numpy as np
from numpy.random import normal

# Create 5x5 arrow, normally distributed
a = np.random.randn(5,5)
print(a)

# Replace all number that are higher than 0.09 with their square, and all others with 42
a[a > 0.09] = np.square(a[a > 0.09])
a[a <= 0.09] = 42
print("\n")
print(a)

# Print only the fourth column
print("\n")
print(a[:,3])