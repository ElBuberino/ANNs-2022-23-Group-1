from typing import Any, Union

import sympy as sp
from sympy import *
import numpy as np
import math

# Define symbols for symbolic math
from sympy import Symbol

x = Symbol('x')
a = Symbol('a')
b = Symbol('b')
z = Symbol('z')

# Sigmoid function
sigmoid = 1/(1 + exp(-x))
# Calculate the derivative
sigmoid_prime = sigmoid.diff(x)
print(sigmoid_prime)

# Multivariate function
multivariate = ((4*a*(x**2))+a) + 3 + (1/(1 + exp(-z))) + (1/(1 + exp(-(b**2))))
# Calculate derivative
multivariate_prime_x = multivariate.diff(x)
multivariate_prime_z = multivariate.diff(z)
multivariate_prime_a = multivariate.diff(a)
multivariate_prime_b = multivariate.diff(b)

print("\n")
print(multivariate_prime_x)
print(multivariate_prime_z)
print(multivariate_prime_a)
print(multivariate_prime_b)

# Create gradient of multivariate function
gradient_multivariate = np.array([[multivariate_prime_x],[multivariate_prime_z],[multivariate_prime_a],[multivariate_prime_b]])
print("\n")
print(gradient_multivariate)

